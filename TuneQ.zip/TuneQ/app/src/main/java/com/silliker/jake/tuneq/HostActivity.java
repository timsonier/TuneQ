package com.silliker.jake.tuneq;

import android.annotation.TargetApi;
import android.app.Fragment;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.Intent;
import android.os.Build;
import android.os.StrictMode;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import com.firebase.client.ChildEventListener;
import com.firebase.client.DataSnapshot;
import com.firebase.client.Firebase;
import com.firebase.client.FirebaseError;
import com.firebase.client.ValueEventListener;
import com.spotify.sdk.android.authentication.AuthenticationClient;
import com.spotify.sdk.android.authentication.AuthenticationRequest;
import com.spotify.sdk.android.authentication.AuthenticationResponse;
import com.spotify.sdk.android.player.Config;
import com.spotify.sdk.android.player.Player;
import com.spotify.sdk.android.player.PlayerNotificationCallback;
import com.spotify.sdk.android.player.PlayerState;
import com.spotify.sdk.android.player.Spotify;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Serializable;
import java.io.StringReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

import javax.json.Json;
import javax.json.stream.JsonParser;

public class HostActivity extends AppCompatActivity {

    Firebase firebaseRef;

    //the unique id that will serve as the root directory for this host's playlist in firebase
    final String hostName = "111";

    //Spotify identifiers
    private static final String CLIENT_ID = "9752ab05bf9d4e0fb902b08bffe6b975";
    private static final String REDIRECT_URI = "tuneq://callback";

    // Request code that will be used to verify if the result comes from correct activity
    // Can be any integer
    private static final int REQUEST_CODE = 2063;
    private Player mPlayer;

    boolean isPlaying = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_host);
        //needed this to be able to return JSON from spotify
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        //Spotify authetication Stuff
        AuthenticationRequest.Builder builder = new AuthenticationRequest.Builder(CLIENT_ID,
                AuthenticationResponse.Type.TOKEN,
                REDIRECT_URI);
        builder.setScopes(new String[]{"user-read-private", "streaming"});
        AuthenticationRequest request = builder.build();

        AuthenticationClient.openLoginActivity(this, REQUEST_CODE, request);


        //Firebase stuff
        Firebase.setAndroidContext(this);
        firebaseRef = new Firebase("https://sizzling-inferno-1580.firebaseio.com/hosts/" + hostName);

        //add the playlist fragment programmatically
        FragmentManager fragmentManager = getFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        PlaylistFragment playlistFragment = new PlaylistFragment();

        // pass the host id to PlaylistFragment in a Bundle
        Bundle b = new Bundle();
        b.putString("hostname", hostName);
        playlistFragment.setArguments(b);

        fragmentTransaction.add(R.id.activity_host, playlistFragment);
        fragmentTransaction.commit();

        //Play/Pause Button

        Button playPause = (Button) findViewById(R.id.playPause);

        playPause.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Log.i("TAG", "button clicked");
                if (isPlaying) {
                    mPlayer.pause();
                    isPlaying = false;
                    Log.i("TAG", "isPlaying == false");
                } else {
                    mPlayer.resume();
                    isPlaying = true;
                    Log.i("TAG", "isPlaying == true");
                }
            }
        });


    }
    protected void onActivityResult(int requestCode, int resultCode, Intent intent) {
        super.onActivityResult(requestCode, resultCode, intent);

        // Check if result comes from the correct activity
        if (requestCode == REQUEST_CODE) {
            AuthenticationResponse response = AuthenticationClient.getResponse(resultCode, intent);
            if (response.getType() == AuthenticationResponse.Type.TOKEN) {
                Config playerConfig = new Config(this, response.getAccessToken(), CLIENT_ID);
                Spotify.getPlayer(playerConfig, this, new Player.InitializationObserver() {
                    @Override
                    public void onInitialized(Player player) {
                        mPlayer = player;
                         //    mPlayer.addConnectionStateCallback(HostActivity.this);
                        //     mPlayer.addPlayerNotificationCallback(MainActivity.this);
                        Song song = new Song("Bruce Springsteen", "Born in the USA");
                        try {
                            playSong(song);
                        } catch (Exception e){
                            e.printStackTrace();
                        }


                       // mPlayer.play("spotify:track:0yJqMTbkajyRhmwSjCd8Kq");
                    }

                    @Override
                    public void onError(Throwable throwable) {
                        Log.e("MainActivity", "Could not initialize player: " + throwable.getMessage());
                    }
                });
            }
        }
    }


    public void onLoggedIn() {
        Log.d("MainActivity", "User logged in");
    }


    public void onLoggedOut() {
        Log.d("MainActivity", "User logged out");
    }


    public void onLoginFailed(Throwable error) {
        Log.d("MainActivity", "Login failed");
    }


    public void onTemporaryError() {
        Log.d("MainActivity", "Temporary error occurred");
    }


    public void onConnectionMessage(String message) {
        Log.d("MainActivity", "Received connection message: " + message);
    }


    public void onPlaybackEvent(PlayerNotificationCallback.EventType eventType, PlayerState playerState) {
        Log.d("MainActivity", "Playback event received: " + eventType.name());
    }


    public void onPlaybackError(PlayerNotificationCallback.ErrorType errorType, String errorDetails) {
        Log.d("MainActivity", "Playback error received: " + errorType.name());
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    @TargetApi(Build.VERSION_CODES.KITKAT)
    protected void playSong(Song song) throws IOException {
       // String uriString;
      //  URI uri;
       // String query ="";
        String requestURL = "https://api.spotify.com/v1/search?q=artist:nirvana%20track:where+did+you+sleep%20&type=track";
        try {

            HttpURLConnection connection = null;
            connection = (HttpURLConnection) new URL(requestURL)
                    .openConnection();
            InputStream inputStream = connection.getInputStream();

            // Convert the InputStream to String
            StringBuffer sb = new StringBuffer();
            BufferedReader br = null;
            try {
                br = new BufferedReader(new InputStreamReader(inputStream));
                String temp;
                while ((temp = br.readLine()) != null) {
                    sb.append(temp);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            mPlayer.play(processJSON(sb, song));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    private String processJSON(StringBuffer sb, Song dong) {
        String jsonString = sb.toString();
        JsonParser parser = Json.createParser(new StringReader(jsonString));
        boolean artistTrigger = false;
        String uriString ="";

        Song song = new Song("Nirvana", "Where did you sleep last night");


        System.out.println("ProcessJSON entered");
        // Finally, parse resultant JSON
        try {
            while (parser.hasNext()) {

                JsonParser.Event event = parser.next();
                switch (event) {
                    case KEY_NAME:
                        if (parser.getString().equals("name")) {
                            artistTrigger = true;
                            System.out.println("name found");
                        }
                        // else if (parser.getString().equals("name")) {
                        //     trackTrigger = true;
                        //    System.out.println("Track");
                        // }
                        break;
                    case VALUE_STRING:
                        if (parser.getString().equals(song.getArtist())) {
                            //    GeoData geoData = new GeoData();
                            //     geoData.title = parser.getString();
                            //     geoDataArray.add(geoData);
                            // event = parser.next();

                            // System.out.println(event);
                            if (parser.getString().startsWith("spotify:track:")) {
                             //   uri = parser.getString();
                               uriString = parser.getString();
                            }

                            System.out.println(song.getArtist());
                            artistTrigger = false;
                        } else if (artistTrigger && parser.getString().equals(song.getTrack())) {
                            System.out.println(song.getTrack());
                            artistTrigger = false;

                        }
                        break;

                /*case VALUE_NUMBER:
                    if(Trigger && (coordCount == 0) ) {
                     //   GeoData geoData = geoDataArray.get(count);
                     //   geoData.longitude = parser.getString();
                    //    coordCount++;
                    }
                    else if(!coordTrigger && (coordCount == 1)) {
                    //    GeoData geoData = geoDataArray.get(count);
                     //   geoData.latitude = parser.getString();
                    //    coordCount = 0;
                    //    count++;
                    }
                    coordTrigger = false;
                    break;*/
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return uriString;
    }

    }




