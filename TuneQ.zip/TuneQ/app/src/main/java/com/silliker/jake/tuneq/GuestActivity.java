package com.silliker.jake.tuneq;

import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.Intent;
import android.os.Bundle;
import android.os.StrictMode;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Toast;

import com.firebase.client.Firebase;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;

import javax.json.Json;
import javax.json.stream.JsonParser;

public class GuestActivity extends AppCompatActivity {

    Firebase firebaseRef;

    String requestURL = "https://api.spotify.com/v1/search?q=artist:";

    //this hostName will come from the QR scan
    private String hostName = "111";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_guest);

        //needed this to be able to return JSON from spotify
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        //initialize firebase
        Firebase.setAndroidContext(this);
        firebaseRef = new Firebase("https://sizzling-inferno-1580.firebaseio.com/");

        //add the playlist fragment programmatically
        FragmentManager fragmentManager = getFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        PlaylistFragment playlistFragment = new PlaylistFragment();

        // pass the host id to PlaylistFragment in a Bundle
        Bundle b = new Bundle();
        b.putString("hostname", hostName);
        playlistFragment.setArguments(b);

        fragmentTransaction.add(R.id.activity_guest, playlistFragment);
        fragmentTransaction.commit();

        // wire up the 'request song' fab
        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), RequestPopupActivity.class);
                startActivityForResult(intent, 1);
            }
        });

    }

    // this catches the song request from RequestPopupActivity
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        System.out.println("Caught the intent");

        //normal request code = 1, result code = -1
        //abnormal result code = 0

        if (resultCode != 0) {

            Bundle b = data.getExtras();

            String artist = b.get("artist").toString().trim();
            String track = b.get("track").toString().trim();
            String trackId = (fetchTrackId(artist, track));
            System.out.println(trackId);


            Song request = new Song(artist, track, trackId);

            firebaseRef.child("hosts").child(hostName).push().setValue(request);

            Toast t = Toast.makeText(getApplicationContext(), "Requesting.. " + track + " by " + artist, Toast.LENGTH_SHORT);
            t.show();

        }
    }

    //TODO: this method will fetch the track id (eg "5FZxsHWIvUsmSK1IAvm2pp") for the request using spotify's web api
    //seemingly the best format for the request: https://api.spotify.com/v1/search?q=artist:"foo fighters"track:"arlandria"&type=track
    protected String fetchTrackId(String artist, String track) {

       // Song song = new Song(artist, track, "");
        String trackid= "";
        requestURL += "%22" + artist.replace(" ","%20") + "%22" + "track:" + "%22" + track.replace(" ", "%20") + "%22"  + "&type=track";
        System.out.println(requestURL);
        HttpURLConnection connection = null;

        try {
            connection = (HttpURLConnection) new URL(requestURL)
                    .openConnection();
            System.out.println("connection opened successfully");
        } catch (IOException e1) {
            e1.printStackTrace();
        }

        InputStream inputStream = null;

        System.out.println("input stream before try");
        try {
            System.out.println("input stream before");
            inputStream = connection.getInputStream();
            System.out.println("input stream after");
        } catch (IOException e1) {
            e1.printStackTrace();
        }

        // Convert the InputStream to String
        StringBuffer sb = new StringBuffer();
        BufferedReader br = null;
        try {
            br = new BufferedReader(new InputStreamReader(inputStream));
            String temp;
            while ((temp = br.readLine()) != null) {
                sb.append(temp);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        trackid = processJSON(sb, artist, track);

        return trackid;
    }




    private String processJSON(StringBuffer sb, String artist, String track) {
        String jsonString = sb.toString();
        JsonParser parser = Json.createParser(new StringReader(jsonString));
      //  boolean artistTrigger = false;
        String uriString ="";


        System.out.println("ProcessJSON entered");
        // Finally, parse resultant JSON
        try {
            while (parser.hasNext()) {
                JsonParser.Event event = parser.next();
                switch (event) {
                    case VALUE_STRING:
                        if (parser.getString().startsWith("spotify:track:")) {
                            uriString = parser.getString();
                            System.out.println(uriString);
                            return uriString;
                        }
                        break;
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }



  /*  //helper methods for properly formatting search address
    protected String parseSongArtist(String artist) {
        for (int i = 0; i < artist.length(); i++) {
            System.out.println(i + ": " + artist);

            if (artist.charAt(i) == ' ') {
                System.out.println("replacing");
                artist = artist.replace(' ', '+');
            }
        }
        return artist;
    }



    protected String parseSongTrack(String track) {
        for (int i = 0; i < track.length(); i++) {
            System.out.println(i + ": " + track);
            if (track.charAt(i) == ' ') {
                System.out.println("replacing");
                track = track.replace(' ', '+');
            }
        }
        return track;
    }*/

}
