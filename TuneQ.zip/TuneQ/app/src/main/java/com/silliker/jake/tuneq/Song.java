package com.silliker.jake.tuneq;

import java.io.Serializable;

/**
 * Created by jake on 24/03/16.
 * POJO to represent a song request
 */
public class Song implements Serializable{

    private String artist;
    private String track;

    public Song(){}

    public Song(String artistIn, String trackIn){
        this.artist = artistIn;
        this.track = trackIn;
    }

    public String getTrack() {
        return track;
    }

    public String getArtist() {
        return artist;
    }
}
