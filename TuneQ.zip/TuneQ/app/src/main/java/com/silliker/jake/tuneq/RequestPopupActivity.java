package com.silliker.jake.tuneq;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class RequestPopupActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_request_popup);

        //setup the 'popup'
        DisplayMetrics dm = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(dm);

        int width = dm.widthPixels;
        int height = dm.heightPixels;

        getWindow().setLayout((int)(width*.8), (int)(height*.8));

        Button btn_request = (Button) findViewById(R.id.btn_request);

        btn_request.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                System.out.println("onclick");

                //get the artist and track string
                EditText et_artist = (EditText) findViewById(R.id.txt_artist);
                EditText et_track = (EditText) findViewById(R.id.txt_track);

                String artist = et_artist.getText().toString();
                String track = et_track.getText().toString();

                //make sure they actually entered some search terms before sending the request
                if(!artist.isEmpty() && !track.isEmpty()) {

                    System.out.println(artist + " " + track);

                    //return this to GuestActivity
                    Intent result = new Intent();
                    result.putExtra("artist", artist);
                    result.putExtra("track", track);
                    setResult(Activity.RESULT_OK, result);
                    finish();

                }
                else{
                    System.out.println("artist or track empty");
                    Toast t = Toast.makeText(getApplicationContext(), "Please enter both Artist and Track", Toast.LENGTH_LONG);
                    t.show();
                }
            }
        });

    }
}
