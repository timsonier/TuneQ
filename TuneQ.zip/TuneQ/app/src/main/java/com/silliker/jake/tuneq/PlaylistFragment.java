package com.silliker.jake.tuneq;

import android.app.Fragment;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.firebase.client.Firebase;
import com.firebase.ui.FirebaseListAdapter;
import com.firebase.ui.FirebaseRecyclerAdapter;

import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.List;


public class PlaylistFragment extends Fragment {

    private static final String TAG = "RecyclerViewFragment";
    private static final String KEY_LAYOUT_MANAGER = "layoutManager";
    private static final int DATASET_COUNT = 60;

    protected RecyclerView mRecyclerView;
    protected RecyclerView.LayoutManager mLayoutManager;
    protected String hostName;
    protected Firebase firebaseRef;

    //protected List<Song> mDataSet;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        hostName = getArguments().get("hostname").toString();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        Firebase.setAndroidContext(getActivity());
        firebaseRef = new Firebase("https://sizzling-inferno-1580.firebaseio.com/hosts/" + hostName);

        View rootView = inflater.inflate(R.layout.fragment_playlist, container, false);
        rootView.setTag(TAG);

        mRecyclerView = (RecyclerView) rootView.findViewById(R.id.recyclerview_playlist);
        mRecyclerView.setHasFixedSize(true);



        // LinearLayoutManager is used here, this will layout the elements in a similar fashion
        // to the way ListView would layout elements. The RecyclerView.LayoutManager defines how
        // elements are laid out.
        mLayoutManager = new LinearLayoutManager(getActivity());

        mRecyclerView.setLayoutManager(mLayoutManager);

        FirebaseRecyclerAdapter<Song, SongViewHolder> adapter = new FirebaseRecyclerAdapter<Song,
                SongViewHolder>(Song.class, R.layout.item_view, SongViewHolder.class, firebaseRef) {
            @Override
            protected void populateViewHolder(SongViewHolder viewHolder, Song song, int i) {
                Log.i(TAG, "Populating");
                //viewHolder.mTextView.setText(song.getArtist() + " " + song.getTrack());
                viewHolder.mArtistView.setText(song.getArtist());
                viewHolder.mTrackView.setText(song.getTrack());
            }
        };

        mRecyclerView.setAdapter(adapter);
      //  System.out.print("child count" + mRecyclerView.getChildCount());
      //  System.out.print("child at 2" + mRecyclerView.getChildAt(2));

        return rootView;
    }

    @Override
    public void onSaveInstanceState(Bundle savedInstanceState) {
        super.onSaveInstanceState(savedInstanceState);
    }

    public static class SongViewHolder extends RecyclerView.ViewHolder {

        public TextView mTextView;
        public TextView mArtistView;
        public TextView mTrackView;

        public SongViewHolder(View v) {
            super(v);
            //mTextView = (TextView) v.findViewById(R.id.item_text_view);
            mArtistView = (TextView) v.findViewById(R.id.item_text_artist);
            mTrackView = (TextView) v.findViewById(R.id.item_text_track);
        }
    }


}
